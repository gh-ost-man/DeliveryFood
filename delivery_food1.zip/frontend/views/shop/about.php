<?php

$this->title = 'About us';
$this->params['breadcrumbs'][] = $this->title;
?>


<div class="mb-3">
    <h1 class="text-center">About us</h1>
    <hr style="border: 1px solid black;">
    <div class="card border-0" style="max-width: 100%;">
        <div class="row no-gutters">
            <div class="col-md-6">
                <img src="\images\about\about.jpg" >
            </div>
            <div class="col-md-6">
                <div class="card-body">
                    <p class="card-text text-justify">
                        Food Deivery це команда професіоналів та ентузіастів смачної кухні, яка Вас ніколи не підведе. Ми готуємо смачні та корисні страви японської та італійської кухонь та швидко доставляємо їх прямісінько до Вас по всьому м. Львів.
                        Якість та Швидкість!  - це два основних пріоритети в роботі команди. 
                        В першу чергу звичайно ж Якість. Суші та Піца готуються без затримок, одразу ж після Вашого замовлення. А завдяки сучасним технологіям та відповідальному навчанню працівників, свіжі страви можливо доставляти до 29хв в 75% замовлень.
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>